/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */
package com.mycompany.studenttrack;

/**
 *
 * @author acer
 */
public class StudentTrack {

    public static void main(String[] args) {

    }
}
