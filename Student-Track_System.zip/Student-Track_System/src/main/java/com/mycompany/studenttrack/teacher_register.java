/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.studenttrack;

/**
 *
 * @author acer
 */
public class teacher_register {

    String name_surname;
    String email;
    String password;

}
